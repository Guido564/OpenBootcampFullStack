def areaTriangulo(base, altura):
    return (base * altura) // 2

print(areaTriangulo(4, 3))

def areaCirculo(radio):
    return 3.14 * (radio * radio)

print(areaCirculo(8))