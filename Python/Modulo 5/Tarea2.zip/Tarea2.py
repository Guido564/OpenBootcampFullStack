def numeroPrimo(numero):
    for i in range(2, numero):
        if (numero % i) == 0:
           print("Es primo")
           break
    else:
        print("No es primo")
        
        
         
numeroPrimo(17)