f = open("miFichero.txt", "w+")
f.write("Hola soy un fichero de datos")
f.close()

