numeros = []
for numero in range(0, 101):
    numeros.append(numero)
print(sorted(numeros, reverse=True))