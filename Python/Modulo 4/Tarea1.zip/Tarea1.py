edad = int(input("Seria tan amable de ingresar su edad estimado? "))

if(edad >= 18):
    print("El usuario es mayor de edad")
else:
    print("El usuario es menor de edad y no deberia estar en este codigo")